from pathlib import Path
from html import escape
from datetime import date
import json
import os

ROOT = Path(__file__).resolve().parents[1] / 'client/public'
BASE = os.getenv('SITE_URL', 'https://hoikunote-rhueltws.manus.space').rstrip('/')
TODAY = os.getenv('CONTENT_DATE', '2026-09-15')
articles = json.loads((Path(__file__).resolve().parents[1] / 'content/articles.json').read_text())

css = '''body{margin:0;background:#fbfaf7;color:#2c414d;font-family:Arial,"Noto Sans JP",sans-serif;line-height:1.9}a{color:#d87360;text-decoration:none}.wrap{max-width:860px;margin:auto;padding:28px 22px 80px}.site{border-top:5px solid #e7826b;border-bottom:1px solid #e8e3da;padding:15px 22px;background:#fffdfa}.site-inner{max-width:1180px;margin:auto;display:flex;justify-content:space-between;align-items:center}.brand{font-weight:800;color:#2c414d}.brand small{display:block;color:#8a9692;font-size:9px;letter-spacing:.15em}.nav{display:flex;gap:18px;font-size:12px}.crumb{margin:24px 0;color:#89938f;font-size:12px}.crumb a{color:#738b82}.label{display:inline-block;color:#d87360;font-size:11px;font-weight:700;letter-spacing:.12em}.summary{margin:25px 0;padding:20px 24px;border-radius:14px;background:#fff0e8;border-left:4px solid #e7826b}.summary strong{display:block;margin-bottom:8px;color:#bd6655}.summary ul{margin:0;padding-left:20px}.story{padding:18px 21px;background:#edf3ef;border-radius:12px;color:#5e7070}.check{padding:19px 22px;background:#fff;border:1px solid #e6e0d8;border-radius:12px}.check li{margin:5px 0}.article h1{font-size:clamp(28px,5vw,50px);line-height:1.3;letter-spacing:-.05em;margin:18px 0;color:#293e4a}.article h2{font-size:24px;margin:50px 0 14px;border-bottom:1px solid #e7e1d8;padding-bottom:10px}.article h3{font-size:18px}.article p{color:#5f6e73}.related{display:grid;gap:10px;margin-top:20px}.related a{display:block;padding:12px 16px;background:#fff;border:1px solid #e6e0d8;border-radius:9px;color:#49676a}.author{margin-top:50px;padding:22px;background:#e9f1ed;border-radius:14px}.faq{margin-top:45px}.faq details{padding:14px 0;border-bottom:1px solid #e5e0d8}.faq summary{cursor:pointer;font-weight:700;color:#455d62}.footer{margin-top:60px;padding-top:20px;border-top:1px solid #e8e3da;color:#8a9591;font-size:12px}@media(max-width:600px){.nav{display:none}.wrap{padding:18px 17px 55px}.article h2{font-size:21px}}'''

def page(a):
    url = f'{BASE}/articles/{a["slug"]}/index.html'
    breadcrumb = [{'@type':'ListItem','position':1,'name':'保育ノート','item':BASE+'/'},{'@type':'ListItem','position':2,'name':'記事一覧','item':BASE+'/#topics'},{'@type':'ListItem','position':3,'name':a['keyword'],'item':url}]
    faq = [{'@type':'Question','name':q,'acceptedAnswer':{'@type':'Answer','text':ans}} for q,ans in a['faqs']]
    related = [x for x in articles if x['slug'] != a['slug']][:3]
    return f'''<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{escape(a['title'])}</title><meta name="description" content="{escape(a['description'])}"><link rel="canonical" href="{url}"><style>{css}</style><script type="application/ld+json">{__import__('json').dumps({'@context':'https://schema.org','@type':'BreadcrumbList','itemListElement':breadcrumb},ensure_ascii=False)}</script><script type="application/ld+json">{__import__('json').dumps({'@context':'https://schema.org','@type':'FAQPage','mainEntity':faq},ensure_ascii=False)}</script></head><body><header class="site"><div class="site-inner"><a class="brand" href="{BASE}/">保育ノート<small>HOIKU NOTE</small></a><nav class="nav"><a href="{BASE}/#topics">悩みから探す</a><a href="{BASE}/#article">読みもの</a><a href="https://hoiku.proreach.co.jp/rl/instagram_aya-7sqz" target="_blank" rel="noreferrer">無料相談</a></nav></div></header><main class="wrap article"><nav class="crumb" aria-label="パンくず"><a href="{BASE}/">トップ</a>　&gt;　<a href="{BASE}/#topics">記事一覧</a>　&gt;　{escape(a['keyword'])}</nav><span class="label">{escape(a['category'])}　/　2026.09.15</span><h1>{escape(a['title'])}</h1><div class="summary"><strong>この記事の結論</strong><ul>{''.join(f'<li>{escape(x)}</li>' for x in a['summary'])}</ul></div><p>{escape(a['story'])}</p><h2>こんな悩みありませんか？</h2><p>{escape(a['body'])}</p><div class="check"><strong>セルフチェック</strong><ul><li>職場で相談できる人がいない</li><li>休みや給与の条件を説明されていない</li><li>出勤前から気持ちが重い日が続く</li></ul><p>3つ以上当てはまる場合は、記事の対処法を試しながら、外部相談や環境を変える選択肢も検討してみてください。</p></div><h2>今日からできる対処法</h2><p>{escape(a['body'])}</p><h2>関連する記事</h2><div class="related">{''.join(f'<a href="{BASE}/articles/{x["slug"]}/index.html">{escape(x["keyword"])}</a>' for x in related)}</div><section class="faq"><h2>よくある質問</h2>{''.join(f'<details><summary>{escape(q)}</summary><p>{escape(ans)}</p></details>' for q,ans in a['faqs'])}</section><div class="author"><strong>執筆・編集：保育ノート編集部</strong><p>保育現場での勤務経験者と、保育士の転職・働き方を取材してきた編集メンバーが、制度や職場選びの情報を整理しています。個別の法律・医療判断は専門窓口へご確認ください。</p></div><footer class="footer"><a href="{BASE}/">保育ノート トップへ戻る</a></footer></main></body></html>'''

for a in articles:
    path = ROOT / 'articles' / a['slug'] / 'index.html'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(page(a), encoding='utf-8')

sitemap = ['<?xml version="1.0" encoding="UTF-8"?>','<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',f'<url><loc>{BASE}/</loc><lastmod>{TODAY}</lastmod><priority>1.0</priority></url>']
for a in articles:
    sitemap.append(f'<url><loc>{BASE}/articles/{a["slug"]}/index.html</loc><lastmod>{TODAY}</lastmod><changefreq>monthly</changefreq><priority>0.8</priority></url>')
sitemap.append('</urlset>')
(ROOT/'sitemap.xml').write_text('\n'.join(sitemap), encoding='utf-8')
(ROOT/'robots.txt').write_text(f'User-agent: *\nAllow: /\nSitemap: {BASE}/sitemap.xml\n', encoding='utf-8')
print(f'generated {len(articles)} article pages')
print('sitemap', ROOT/'sitemap.xml')
print('robots', ROOT/'robots.txt')
