"""LINE CTAの視認性・転換率を高めるための追加パッチ。

add_article_ctas.py が既に data-cta-version="1" を注入した記事に対して実行する。
- summary直後に「top」タッチポイントを追加（結論を読んだ直後の早い離脱を拾う）
- header / floatingボタンに控えめなパルスアニメーションを追加（prefers-reduced-motionは尊重）
- header / floatingのコピーを行動喚起の強い文言に変更
- floating CTAの表示トリガーを50%スクロールから28%スクロールに前倒し
"""
from pathlib import Path

root = Path(__file__).resolve().parents[1] / 'client/public/articles'

extra_css = '''@keyframes ctaPulse{0%{box-shadow:0 0 0 0 rgba(6,199,85,.45)}70%{box-shadow:0 0 0 9px rgba(6,199,85,0)}100%{box-shadow:0 0 0 0 rgba(6,199,85,0)}}.article-header-cta,.floating-cta button{animation:ctaPulse 2.4s infinite}@media(prefers-reduced-motion:reduce){.article-header-cta,.floating-cta button{animation:none}}.top-cta{display:flex;align-items:center;gap:10px;margin:14px 0 30px;padding:12px 16px;border-radius:999px;background:#effbf3;border:1px solid #b9e8c9;font-size:12px;color:#246443;font-weight:700;cursor:pointer;width:fit-content}.top-cta:hover{background:#e3f6e9}.top-cta .line-icon{margin-right:0}@media(max-width:600px){.top-cta{width:100%;box-sizing:border-box}}'''

icon = '<span class="line-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 11.5c0 4.1-3.6 7.5-8 7.5-1.1 0-2.1-.2-3-.5L4 20l1.1-3.2A7 7 0 0 1 4 11.5C4 7.4 7.6 4 12 4s8 3.4 8 7.5Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></svg></span>'

updated = 0
for path in sorted(root.glob('*/index.html')):
    text = path.read_text()
    if 'data-cta-version="1"' not in text:
        continue  # 先に add_article_ctas.py を実行してください
    if 'data-cta-version="2"' in text:
        continue  # 適用済み

    # 1) summary直後にtopタッチポイントを追加
    top_cta = (
        f'<button class="top-cta" data-line-position="top" data-cta-version="2">'
        f'{icon}<span>同じ悩みを持つ保育士からのLINE相談を受け付けています</span></button>'
    )
    marker = '</div><p>'
    idx = text.find('<div class="summary">')
    if idx != -1:
        close_idx = text.find(marker, idx)
        if close_idx != -1:
            insert_at = close_idx + len('</div>')
            text = text[:insert_at] + top_cta + text[insert_at:]

    # 2) コピーを強化
    text = text.replace('>無料相談</button>', '>今すぐ無料相談</button>')
    text = text.replace('<span>悩みを一人で抱えないで</span>', '<span>一人で抱えなくて大丈夫です</span>')
    text = text.replace(
        f'{icon}LINEで相談</button>',
        f'{icon}今すぐ相談する</button>'
    )

    # 3) floating CTAの表示トリガーを前倒し（50% -> 28%スクロール）
    text = text.replace('window.scrollY/max>=.5', 'window.scrollY/max>=.28')

    # 4) パルスアニメーション等の追加CSS
    text = text.replace('</style>', extra_css + '</style>', 1)

    path.write_text(text)
    updated += 1

print('CTA強化を適用した記事数:', updated)
