# 保育ノート（hoiku-note）

保育士向けの悩み解決メディアです。React + Vite + TypeScriptでトップページを構築し、検索流入を目的とする9記事は、JavaScriptを実行しなくても本文を取得できる静的HTMLとして `client/public/articles/` に生成します。

## 技術構成

- React 19 / TypeScript
- Vite 7 / Tailwind CSS 4
- Wouter（トップページ側のクライアントルーティング）
- 静的SEO記事：HTML + JSON-LD（BreadcrumbList / FAQPage）
- 依存関係管理：pnpm推奨（npmでも実行可能）

`server/` はWebDevテンプレート互換のプレースホルダーです。記事ページ・sitemap・robotsはバックエンドAPIを使わず、ビルド時に静的ファイルとして配信します。

## ローカル起動

```bash
# 推奨
pnpm install
pnpm dev

# npmを使う場合
npm install
npm run dev
```

開発サーバーは通常 `http://localhost:3000` で起動します。トップページは `/`、記事は `/articles/<slug>/index.html` です。

## 環境変数

GitHubへ公開する際は、`.env.example` を `.env` にコピーして値を差し替えます。実際のAPIキーや個人情報はコミットしないでください。

| 変数 | 用途 | 必須 |
|---|---|---|
| `SITE_URL` | 生成するcanonical URL、sitemap、robotsの基準URL | 本番では必須 |
| `CONTENT_DATE` | 記事HTMLへ出力する更新日 | 任意 |
| `GA4_MEASUREMENT_ID` | GA4の測定ID。未設定または`REPLACE`のままならGA4スクリプトを読み込みません | 任意 |
| `LINE_URL` | LINE相談先。CTA生成時に使用 | 任意（既定値あり） |

GA4を有効化する場合は、次を実行してトップと全記事HTMLへタグを注入します。

```bash
GA4_MEASUREMENT_ID=G-XXXXXXXXXX npm run seo:ga4
```

## 開発・ビルド

```bash
npm run check
npm run build
```

- `npm run check`：TypeScript型チェック
- `npm run build`：Viteでフロントを `dist/public/` へ出力し、テンプレートのサーバーバンドルを `dist/index.js` へ出力
- `npm run preview`：ビルド後のフロントをプレビュー

依存関係のバージョンを固定するため、`pnpm-lock.yaml` もリポジトリへ含めてください。

## 記事データと記事追加手順

9記事の元データは `content/articles.json` で管理しています。各記事は次の項目を持ちます。

- `slug`：URLに使う一意のスラッグ
- `keyword`：パンくずと記事一覧に表示する主キーワード
- `title`：記事のtitleとh1
- `description`：meta description
- `category`、`summary`、`story`、`body`、`faqs`：記事本文と構造化データ用のコンテンツ

新しい記事を追加する場合は、次の手順です。

1. `content/articles.json` に記事オブジェクトを1件追加する。`slug` は既存記事と重複させない。
2. `client/src/pages/Home.tsx` の `topics` 配列へ一覧カードを追加する。トップに表示しない場合は省略可能。
3. `.env` の `SITE_URL` と `CONTENT_DATE` を確認する。
4. 次の生成コマンドを実行する。

```bash
npm run seo:generate
npm run seo:urls
npm run seo:cta
npm run seo:cta:boost
npm run seo:ga4
```

5. `npm run check && npm run build` で確認する。
6. `client/public/articles/<slug>/index.html`、`client/public/sitemap.xml`、`client/public/robots.txt` の差分を確認してコミットする。

記事HTMLは生成物ですが、現在の静的ホスティングでそのまま公開できるよう、リポジトリにも含めます。

## sitemap.xml / robots.txt

手動編集ではありません。`scripts/generate_seo_pages.py` が `content/articles.json` を読み込み、次を自動生成します。

- `client/public/sitemap.xml`：トップURLと全記事URL
- `client/public/robots.txt`：全体許可とsitemapの場所
- `client/public/articles/<slug>/index.html`：title、description、h1、パンくず、BreadcrumbList、FAQPage、本文

`SITE_URL` を変更した場合は、必ず `npm run seo:generate` と `npm run seo:urls` を再実行してください。

## LINE相談CTAと計測

`scripts/add_article_ctas.py` が各静的記事へCTAを注入します。記事ヘッダー、中盤、記事末、50%スクロール後のスマホ固定CTAは、すべて相談内容を表示する同一モーダルを経由します。CTAの色・文言・LINE URLは同スクリプト内の設定値（`line_url`、`CTA_CONFIG`、`#06C755`）に集約しています。

モーダル表示時とLINE遷移時に、次のイベントを発火します。

```js
gtag('event', 'line_cta_click', {
  article: '<slug>',
  position: 'header' | 'mid' | 'bottom' | 'floating',
  step: 'modal_open' | 'line_redirect'
});
```

GA4測定IDが未設定の場合も、サイト自体と`dataLayer`のイベント処理は動作します。

### CTAの視認性強化（`npm run seo:cta:boost`）

`scripts/strengthen_line_cta.py` は `add_article_ctas.py` 実行後の記事に追加パッチを当て、LINE相談への転換率を上げるための変更を加えます（`data-cta-version="2"`が目印。二重適用は自動でスキップされます）。

- 結論要約の直後に「top」タッチポイントを追加し、記事を読み始めてすぐ離脱する読者も拾う
- header・floatingボタンに控えめなパルスアニメーションを付与（`prefers-reduced-motion`環境ではアニメーションなし）
- header・floatingのコピーをより行動喚起の強い文言に変更（例：「無料相談」→「今すぐ無料相談」）
- floating CTAの表示トリガーをスクロール50%から28%に前倒しし、露出機会を増やす

新しい記事を追加する際は、`seo:generate` → `seo:urls` → `seo:cta` → `seo:cta:boost` → `seo:ga4` の順に実行してください。

## Manusでのデプロイ

Manus WebDevプロジェクトとして開く場合は、プロジェクトルートを読み込んで依存関係をインストールし、`npm run check && npm run build` を通します。WebDevのプレビューでトップと記事URLを確認した後、WebDevの公開／チェックポイント機能から公開します。公開先ドメインはManus側で発行されます。

GitHubへ移行した後は、GitHub Actions、Vercel、Netlify、Cloudflare Pagesなど、静的ホスティングで `npm run build` を実行し、`dist/public/` を公開ディレクトリに指定できます。Manus独自の `/manus-storage/` 依存を避けるため、ヒーロー画像は `client/public/assets/hoiku-note-hero.jpg` に同梱しています。

## GitHubへ移行する際の注意

- `.env`、APIキー、OAuth秘密情報はコミットしない。
- `node_modules/`、`dist/`、`.manus-logs/` は `.gitignore` で除外する。
- `package.json`、`pnpm-lock.yaml`、`client/`、`content/`、`scripts/`、`client/public/articles/` はコミット対象。
- Manusで生成した `.project-config.json` は環境固有情報のため、GitHubで使わない場合はコミットしない。
